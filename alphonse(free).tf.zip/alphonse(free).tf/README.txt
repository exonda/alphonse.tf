<!—alphonse.ttf is a free to use type, made out of artificial intelligence logic systems.—>  <!—Thanks for downloading 🙏—>
<!—open on dm to answer—>
	/*btst.d*/

<!— Sept. —> nov. 2025 —> 	-	e.da productions.